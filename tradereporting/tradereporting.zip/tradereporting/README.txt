1. Please start looking at TradingEngineTest to look at the flow
2. Application can be started by running Start.java with no parameters
3. For now Default handlers are used but new handlers can be easily plugged in.
4. Default Report published is on Console
5. Logging done on Console
6. App compiled on Java 9...should work on Java 8 as well. No 9/10 feature used. (Deleted Java 8 on my machine by mistake!)
7. Project is Mavenized to add Junit